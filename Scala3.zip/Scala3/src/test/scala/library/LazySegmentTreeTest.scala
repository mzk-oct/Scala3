package library

import library.category.Monoid
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.should.Matchers
import sun.text.UCompactIntArray
class LazySegmentTreeTest extends AnyFunSuite, Matchers {

  val random = Random(0)


  given Operation[Int, Int] with
    override val zero = 0
    override def apply(operation: Int, operand: Int) = operation + operand
    override def merge(newOperation: Int, oldOperation: Int) = newOperation + oldOperation
  given Monoid[Int] with
    override val zero = 0
    override def plus(left: Int, right: Int) = scala.math.max(left, right)

  class Impl(val size: Int)(using t: Monoid[Int], f: Operation[Int, Int]):
    private val vec = Array.fill(size){t.zero}
    def get(from: Int, until: Int): Int = (from until until).foldLeft(t.zero){(left, idx) => t.plus(left, vec(idx))}
    def get(position: Int): Int = vec(position)
    def apply(from: Int, until: Int, diff: Int) =
      for i <- from until until do
        vec(i) += diff
    def apply(position: Int, diff: Int) =
      vec(position) += diff
    def update(position: Int, value: Int) =
      vec(position) = value

  trait LazySeg[T]:
    def get(from: Int, until: Int): T
    def get(position: Int): T
    def apply(from: Int, until: Int, diff: Int): Unit
    def apply(position: Int, diff: Int): Unit
    def update(position: Int, value: Int): Unit
  class Target(seg: Impl) extends LazySeg[Int]:
    export seg.*
    def this(size: Int) =
      this(Impl(size))
  class Contestant(seg: LazySegmentTree[Int, Int]) extends LazySeg[Int]:
    export seg.*
    def this(size: Int) =
      this(LazySegmentTree[Int, Int](size))

  class Sync(contestant: Contestant, target: Target)
}
