

@main def main(): Unit =
  val x = 0.0 * 1.0
  val range = 0 until 10

  println("Hello World!")